import React from 'react'
import Image2 from '../images/Image2.png'
import Image4 from '../images/Image4.png'
import Image5 from '../images/Image5.png'



const Sidebar = () => {
  return (
    <>
      <div className="side-bar">
        <div className="option">
            <div className="option-icon">
                <i className="fa-solid fa-house"></i>
                <i className="fa-solid fa-angle-right arrow"></i>
            </div>
            <p>Offer</p>
        </div>
        <div className="categories">
            <div className="software">
                <h3>Software</h3>
                <i className="fa-solid fa-angle-right arrow"></i>
            </div>
            <div className="software">
                <h3>Hardware</h3>
                <i className="fa-solid fa-angle-right arrow"></i>
            </div>
            <div className="add-categories">
                <i className="fa-solid fa-square-plus"></i>
                <h3>More Categories</h3>
            </div>
        </div>
        <div className="orci-attahche">
            <h2>Orci Attahche</h2>
            <h3>Get Pricing</h3>
        </div>
        <div className="latest-product">
            <h3>LATEST PRODUCT</h3>
            <div className="products">
                <img src={Image2} alt="image" />
                <div className="info">
                    <h5>Quis ullamcorper</h5>
                    <div className="star">
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
            <div className="products">
                <img src={Image2} alt="image" />
                <div className="info">
                    <h5>Quis ullamcorper</h5>
                    <div className="star">
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
            <div className="products">
                <img  className="acronis" src={Image4} alt="image" />
                <div className="info">
                    <h5>Quis ullamcorper</h5>
                    <div className="star">
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
            <div className="products">
                <img src={Image5} alt="image" />
                <div className="info">
                    <h5>Quis ullamcorper</h5>
                    <div className="star">
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
        </div>
        <div className="orci-attahche">
            <h2>Orci Attahche</h2>
            <h3>Get Pricing</h3>
        </div>
        <div className="latest-product top rated">
            <h3>TOP RATED</h3>
            <div className="products">
                <img src={Image2} alt="image" />
                <div className="info">
                    <h5>Quis ullamcorper</h5>
                    <div className="star">
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
            <div className="products">
                <img src={Image2} alt="image" />
                <div className="info">
                    <h5>Quis ullamcorper</h5>
                    <div className="star">
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
            <div className="products">
                <img  className="acronis" src={Image4} alt="image" />
                <div className="info">
                    <h5>Quis ullamcorper</h5>
                    <div className="star">
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
            <div className="products">
                <img src={Image5} alt="image" />
                <div className="info">
                    <h5>Quis ullamcorper</h5>
                    <div className="star">
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                        <i className="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </>
  )
}

export default Sidebar
