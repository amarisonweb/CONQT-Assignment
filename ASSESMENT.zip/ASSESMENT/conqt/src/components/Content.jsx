import React from 'react'
import Image2 from '../images/Image2.png'

const Content = () => {
  return (
    <>
      <div className="content">
        <div className="flash-sale">
          <div className="sale-info">
            <h2>FLASH SALE</h2>
            <div className="timing">
              <h5>ENDING IN</h5>
              <div className='timing-count'>00</div>
              <p>:</p>
              <div className='timing-count'>00</div>
              <p>:</p>
              <div className='timing-count'>00</div>
            </div>
          </div>
          <div className="sale-cards">
            <div className="sale-card">
              <div className="sale-discount">-30%</div>
              <img src={Image2} alt="image" />
              <h3>SAP</h3>
              <div className="star">
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <h6>4.4</h6>
              </div>
              <div className="about">
                <div className="badge">Features</div>
                <div className="badge">Plan</div>
                <div className="badge">Write Review</div>
              </div>
            </div>
            <div className="sale-card">
              <div className="sale-discount">-30%</div>
              <img src={Image2} alt="image" />
              <h3>SAP</h3>
              <div className="star">
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <h6>4.4</h6>
              </div>
              <div className="about">
                <div className="badge">Features</div>
                <div className="badge">Plan</div>
                <div className="badge">Write Review</div>
              </div>
            </div>
            <div className="sale-card">
              <div className="sale-discount">-30%</div>
              <img src={Image2} alt="image" />
              <h3>SAP</h3>
              <div className="star">
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <h6>4.4</h6>
              </div>
              <div className="about">
                <div className="badge">Features</div>
                <div className="badge">Plan</div>
                <div className="badge">Write Review</div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </>
  )
}

export default Content
