import React from 'react'

const Navbar = () => {
  return (
    <>
        <div className="navbar">
            <div className="logo-bar">
                <div className="search">
                    <h1>CON<span><i className="fa-solid fa-magnifying-glass"></i></span>T</h1>
                    <a href="" className="button">Find Vendor</a>
                    <a href="" className="button">Find Customer</a>                   
                </div>
                
                <div className="profile-bar">
                    <a href="" className="button call"><i class="fa-solid fa-phone"></i><span>Call Exprt</span></a>
                    <div className="profile">
                        <i className="fa-solid fa-bars"></i>
                        <div className="user">
                            <i className="fa-solid fa-user"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div className="menu-bar">
                <div className="menu">
                    <div className="dropdown-menu">
                        <p>All Categories</p>
                        <i className="fa-solid fa-caret-down"></i>
                    </div>
                    <div className="dropdown-menu">
                        <p>By Industry</p>
                        <i className="fa-solid fa-caret-down"></i>
                    </div>
                    <div className="dropdown-menu">
                        <p>By Department</p>
                        <i className="fa-solid fa-caret-down"></i>
                    </div>
                    <div className="dropdown-menu">
                        <a href="">Compare Product</a>
                    </div>
                    <div className="dropdown-menu">
                        <a href="">Sell your Products</a>
                    </div>
                    <div className="dropdown-menu">
                        <a href="">Offer</a>
                    </div>
                </div>
                <div className="review">
                    <div className="review-menu">
                        <a href="">Write Review</a>
                    </div>
                    <div className="review-menu ">
                        <a href="">Need Help</a>
                        <div className="question">
                            <i className="fa-solid fa-question"></i>
                        </div>
                    </div>
                </div>

            </div>
        </div>
      
    </>
  )
}

export default Navbar
