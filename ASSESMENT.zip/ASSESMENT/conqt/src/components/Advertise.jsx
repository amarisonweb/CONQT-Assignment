import React from 'react'
import Image1 from '../images/Image1.png'

const Advertise = () => {
  return (
    <>
      <div className="advertiseing">
        <div className="picture">
            <div className="logo-name">
                druva
            </div>
            <div className="image">
                <img src={Image1} alt="image" />
            </div>
            
        </div>
        <div className="description">
            <div className="info">
                <h1>druva</h1>
                <h3>Get Your</h3>
                <h3>Favorite Discount</h3>
                <h3 className='discount'>30% OFF</h3>
                <a href="" className="button shop-btn">Shop Now</a>
            </div>
            <a href="" className="discount-btn">FLAT 30% OFF</a>
        </div>
      </div>
    </>
  )
}

export default Advertise
