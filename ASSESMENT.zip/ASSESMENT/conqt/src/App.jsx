
import './App.css'
import Navbar from './components/Navbar'
import Advertise from './components/Advertise'
import Main from './components/Main'

function App() {

  return (
    <>
      <div>
        <Navbar />
        <Advertise />
        <Main />
      </div>
    </>
  )
}

export default App
